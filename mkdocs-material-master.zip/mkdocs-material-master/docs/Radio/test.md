# 插入视频测试

<video src="https://sbboss-image.oss-cn-hongkong.aliyuncs.com/img/gmy.mp4"></video>

# 音频测试

<audio src="https://sbboss-image.oss-cn-hongkong.aliyuncs.com/img/%E4%B9%85%E8%BF%9D%E4%BA%86%E5%8D%8A%E5%90%8A%E5%AD%90%E5%B7%A5%E7%A8%8B%E5%B8%88%E7%9A%84%E5%90%AC%E4%BC%97.mp3"></audio>

